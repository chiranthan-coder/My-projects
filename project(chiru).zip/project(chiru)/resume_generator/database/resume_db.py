import sqlite3
from datetime import datetime

def create_database():
    conn = sqlite3.connect('database/resumes.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS resumes
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT,
                  email TEXT,
                  phone TEXT,
                  dob TEXT,
                  address TEXT,
                  nationality TEXT,
                  linkedin TEXT,
                  skills TEXT,
                  languages TEXT,
                  hobbies TEXT,
                  objective TEXT,
                  experience TEXT,
                  education TEXT,
                  declaration TEXT,
                  photo TEXT,
                  created_at TEXT)''')
    conn.commit()
    conn.close()

def save_resume(data):
    conn = sqlite3.connect('database/resumes.db')
    c = conn.cursor()
    
    c.execute('''INSERT INTO resumes 
                 (name, email, phone, dob, address, nationality, linkedin, 
                  skills, languages, hobbies, objective, experience, education, 
                  declaration,photo, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
              (data['name'], data['email'], data['phone'], data['dob'],
               data['address'], data['nationality'], data['linkedin'],
               ', '.join(data['skills']), ', '.join(data['languages']),
               ', '.join(data['hobbies']), data['objective'],
               data['experience'], data['education'], data['declaration'],
               data['photo'],
               datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    
    conn.commit()
    conn.close()
    return c.lastrowid

def get_resume(resume_id):
    conn = sqlite3.connect('database/resumes.db')
    c = conn.cursor()
    
    c.execute('SELECT * FROM resumes WHERE id = ?', (resume_id,))
    resume = c.fetchone()
    conn.close()
    
    if resume:
        return {
            'id': resume[0],
            'name': resume[1],
            'email': resume[2],
            'phone': resume[3],
            'dob': resume[4],
            'address': resume[5],
            'nationality': resume[6],
            'linkedin': resume[7],
            'skills': resume[8].split(', '),
            'languages': resume[9].split(', '),
            'hobbies': resume[10].split(', '),
            'objective': resume[11],
            'experience': resume[12],
            'education': resume[13],
            'declaration': resume[14],
            'photo': resume[15],
            'created_at': resume[16]
        }
    return None